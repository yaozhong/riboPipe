# RiboPipe MVP v6

## Fixes in v6
- Streaming preprocess now **always accumulates transcripts across CSV chunks** and no longer drops all transcripts due to FASTA key mismatches.
- Enforced NPZ naming:
  `<CSV_STEM>__<Celltype>_<Genotype>_<Treatment>_<Type>_<Remarks>.npz`
  Example: `TESTDATA260131__HEK293T_WT_NT_mono_TX7.npz`
- Added lightweight progress reporting during streaming (rows processed + accumulated transcript count).

## Typical workflow
```bash
ribopipe preprocess --csv TESTDATA260131.csv --fasta gencode.fa --out-dir out_npz --fasta-cache out_npz/fasta_cache.pkl
ribopipe matrix --npz-dir out_npz --out-csv out_npz/coverage_matrix_transcript_x_sample.csv
```