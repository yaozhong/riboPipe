#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ribo-seq pipeline:
- Read coverage matrix (transcript x sample)
- For each sample's .npz:
  * Select training transcripts by (value > P75/P95) AND (mean CDS RPM > 0.5)
  * Save train list; define pred set
  * Compute k-mer/codon spectra differences (TRAIN vs PRED), output JSD + enrichment
  * Train BiLSTMWithMRL on TRAIN; save model
  * Predict codon-level coverage for PRED; export raw-style NPZ and compact CSV

Optimizations seamlessly integrated (ONLY bottleneck 1/2/4/5; bottleneck 3 unchanged):
- (1) Length-aware batching via sortish sampler + per-batch length sorting
- (2) Dataset stores variable-length tensors once (no per-step rebuilding)
- (4) Packed LSTM to skip padding compute (mask-aware mean for MRL head)
- (5) DataLoader: num_workers/pin_memory/persistent_workers
"""

import os, sys, argparse, json, math, glob
import numpy as np
import pandas as pd
from collections import Counter, defaultdict
import random
import time
from tqdm import tqdm

# ---- torch imports (same file, same behavior) ----
import torch, torch.nn.functional as F
import torch.nn as nn, torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split, Sampler
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from scipy.stats import pearsonr, spearmanr


def set_seed(s):
    # NOTE: keep the original determinism block unchanged (bottleneck 3 not touched)
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)
    torch.cuda.manual_seed_all(s)
    # add additional seed
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms = True


# ---------- quantile, filtering ----------
def compute_threshold(series: pd.Series, which="P75"):
    q = {"P75": 0.75, "P95": 0.95}[which]
    return float(series.quantile(q))


def empirical_cov_mean(cov_1d: np.ndarray) -> float:
    # mean(CDS RPM) = sum(cov)/len(cov). cov = avg_count_norm (assumed RPM-like)
    if cov_1d.size == 0:
        return 0.0
    return float(np.sum(cov_1d))


# ---------- k-mer / codon spectra ----------
CODONS = [a + b + c for a in "ACGT" for b in "ACGT" for c in "ACGT"]
CODON_IDX = {c: i for i, c in enumerate(CODONS)}


def codon_iter(seq: str):
    # step=3 in CDS frame
    L = (len(seq) // 3) * 3
    for i in range(0, L, 3):
        yield seq[i:i + 3]


def codon_freqs_for_set(npz_dict: dict, trans_ids: list) -> np.ndarray:
    cnt = np.zeros(64, dtype=np.float64)
    total = 0
    for tid in trans_ids:
        ent = npz_dict.get(tid, None)
        if ent is None or "cds" not in ent:
            continue
        seq = ent["cds"].get("sequence", "")
        for c in codon_iter(seq):
            idx = CODON_IDX.get(c, None)
            if idx is not None:
                cnt[idx] += 1
                total += 1
    if total == 0:
        return np.ones(64) / 64.0
    return cnt / cnt.sum()


def jsd(P, Q):
    P = np.asarray(P, dtype=np.float64)
    Q = np.asarray(Q, dtype=np.float64)
    P = np.clip(P, 1e-12, 1.0)
    Q = np.clip(Q, 1e-12, 1.0)
    M = 0.5 * (P + Q)

    def kl(A, B):
        return np.sum(A * np.log(A / B))

    return 0.5 * kl(P, M) + 0.5 * kl(Q, M)


def codon_enrichment_log2(P, Q):
    # log2(P/Q)
    P = np.clip(np.asarray(P), 1e-12, 1.0)
    Q = np.clip(np.asarray(Q), 1e-12, 1.0)
    return np.log2(P / Q)


# ---------- IO helpers ----------
def load_npz_as_dict(path):
    z = np.load(path, allow_pickle=True)
    out = {}
    for k in z.files:
        out[k] = z[k].item()
    return out


def save_pred_raw_npz(path, pred_dict):
    # pred_dict: {transcript: {'cds': {'pred_cov': np.ndarray}}}
    np.savez_compressed(path, **{k: pred_dict[k] for k in pred_dict})


def save_pred_compact_csv(path, pred_dict):
    with open(path, "w") as f:
        for tid, ent in pred_dict.items():
            arr = ent["cds"]["pred_cov"]
            vals = ",".join([f"{x:.6g}" for x in arr])
            f.write(f"{tid},{vals}\n")


# ---------- Model code (optimized, but same task/outputs) ----------
class CodonCoverageDataset(Dataset):
    """
    Variable-length dataset:
      returns (tid, codon_onehot[L,64], bio_feat[L,D], cov[L], mrl_scalar, length_L)
    Padding/mask are built in collate_fn so batches waste much less compute.
    """

    def __init__(self, cds_file, bio_feat_file=None, max_codons=1000, allow_ids=None):
        self.items = []
        cds = np.load(cds_file, allow_pickle=True)

        bio = None
        bio_dim = 6
        if bio_feat_file is not None and os.path.isfile(bio_feat_file):
            bio = np.load(bio_feat_file, allow_pickle=True)
            # infer bio_dim from first item
            for bk in bio.files:
                try:
                    bio_dim = int(bio[bk].shape[1])
                except Exception:
                    bio_dim = 6
                break
        self.bio_dim = bio_dim

        allow_set = set(allow_ids) if allow_ids is not None else None
        cod_tab = {c: i for i, c in enumerate([a + b + c for a in "ACGT" for b in "ACGT" for c in "ACGT"])}

        for k in cds.files:
            if allow_set is not None and k not in allow_set:
                continue
            ent = cds[k].item()
            if "cds" not in ent:
                continue
            seq = ent["cds"].get("sequence", "")
            cov = np.asarray(ent["cds"].get("avg_count_norm", []), np.float32)
            L = int(len(cov))
            if len(seq) != L * 3 or L == 0 or L > max_codons or cov.sum() == 0:
                continue

            # one-hot codon (variable length) - built once, not per step
            oh = torch.zeros(L, 64, dtype=torch.float32)
            for i in range(L):
                idx = cod_tab.get(seq[i * 3:i * 3 + 3], None)
                if idx is not None:
                    oh[i, idx] = 1.0

            # normalize to 0-1 (per-transcript min-max)
            mn, mx = float(cov.min()), float(cov.max())
            cov_norm = (cov - mn) / (mx - mn) if mx > mn else np.zeros_like(cov)
            cov_t = torch.tensor(cov_norm, dtype=torch.float32)
            mrl_norm = torch.tensor(float(cov_norm.mean()), dtype=torch.float32)

            # bio features per codon (fallback zeros if missing)
            if bio is not None and k in bio.files:
                bf = torch.tensor(bio[k], dtype=torch.float32)
                if bf.ndim != 2 or bf.shape[0] != L:
                    bf = torch.zeros((L, bio_dim), dtype=torch.float32)
            else:
                bf = torch.zeros((L, bio_dim), dtype=torch.float32)

            self.items.append((k, oh, bf, cov_t, mrl_norm, L))

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        return self.items[idx]


def collate_varlen(batch):
    """
    Build padded batch + mask.
    Returns:
      codon [B,Lmax,64], bio [B,Lmax,D], cov [B,Lmax], mask [B,Lmax] bool, mrl [B], lengths [B], ids [B]
    """
    batch = sorted(batch, key=lambda x: x[5], reverse=True)  # enforce_sorted for pack
    ids, cod_list, bio_list, cov_list, mrl_list, lengths = zip(*batch)
    lengths = torch.tensor(lengths, dtype=torch.long)
    B = len(batch)
    Lmax = int(lengths[0].item())
    bio_dim = int(bio_list[0].shape[1])

    cod = torch.zeros(B, Lmax, 64, dtype=torch.float32)
    bio = torch.zeros(B, Lmax, bio_dim, dtype=torch.float32)
    cov = torch.zeros(B, Lmax, dtype=torch.float32)
    mask = torch.zeros(B, Lmax, dtype=torch.bool)
    mrl = torch.stack(mrl_list)

    for i in range(B):
        l = int(lengths[i].item())
        cod[i, :l] = cod_list[i]
        bio[i, :l] = bio_list[i]
        cov[i, :l] = cov_list[i]
        mask[i, :l] = True

    return cod, bio, cov, mask, mrl, lengths, list(ids)


class SortishBatchSampler(Sampler):
    """Deterministic sortish batching to reduce padding while keeping randomness."""

    def __init__(self, lengths, batch_size, seed=123, chunk_size_mult=50):
        self.lengths = np.asarray(lengths, dtype=np.int32)
        self.batch_size = int(batch_size)
        self.seed = int(seed)
        self.chunk = int(batch_size * chunk_size_mult)

    def __iter__(self):
        rng = np.random.RandomState(self.seed)
        idx = np.arange(len(self.lengths))
        rng.shuffle(idx)

        chunks = [idx[i:i + self.chunk] for i in range(0, len(idx), self.chunk)]
        sorted_idx = []
        for ch in chunks:
            ch = ch[np.argsort(self.lengths[ch])[::-1]]
            sorted_idx.append(ch)
        idx = np.concatenate(sorted_idx) if len(sorted_idx) else idx

        for i in range(0, len(idx), self.batch_size):
            yield idx[i:i + self.batch_size].tolist()

    def __len__(self):
        return math.ceil(len(self.lengths) / self.batch_size)


class BiLSTMWithMRL(nn.Module):
    def __init__(self, input_dim=64, bio_feat_dim=6, hidden_dim=128, fc_dim=64):
        super().__init__()
        total_in = input_dim + bio_feat_dim
        self.l1 = nn.LSTM(total_in, hidden_dim, bidirectional=True, batch_first=True)
        self.l2 = nn.LSTM(hidden_dim * 2, hidden_dim, bidirectional=True, batch_first=True)
        self.fc = nn.Linear(hidden_dim * 2, fc_dim)
        self.regressor = nn.Linear(fc_dim, 1)
        self.mrl_head = nn.Linear(hidden_dim * 2, 1)

    def forward(self, codon, bio_feat, lengths):
        x = torch.cat([codon, bio_feat], dim=-1)  # [B,L,D]
        packed = pack_padded_sequence(x, lengths.cpu(), batch_first=True, enforce_sorted=True)
        h, _ = self.l1(packed)
        h, _ = self.l2(h)
        h, _ = pad_packed_sequence(h, batch_first=True)  # [B,Lmax,2H]

        per_codon = self.regressor(self.fc(h)).squeeze(-1)  # [B,Lmax]

        # length-aware mean for MRL head
        B, Lmax, _ = h.shape
        device = h.device
        mask = (torch.arange(Lmax, device=device)[None, :] < lengths[:, None]).float()
        denom = lengths.float().clamp(min=1.0)
        h_mean = (h * mask[:, :, None]).sum(dim=1) / denom[:, None]
        mrl_pred = self.mrl_head(h_mean).squeeze(-1)  # [B]
        return per_codon, mrl_pred


def mse_mask(pred, tgt, mask):
    return ((pred[mask] - tgt[mask]) ** 2).mean()


def wmse_mask(pred, tgt, mask):
    t = tgt[mask]
    w = 1.0 + 2.0 * ((t > t.mean() + 2 * t.std()).float())
    return ((pred[mask] - t) ** 2 * w).mean()


def bin_acc_mask(pred, tgt, mask, bins=5):
    p = (pred * bins).clamp(0, bins - 1).long()
    t = (tgt * bins).clamp(0, bins - 1).long()
    return (p[mask] == t[mask]).float().mean().item()


def train_model(cds_file, bio_feat_file, epochs=30, train_split=0.8, bio_dim=6, batch_size=64, num_workers=8):
    ds_probe = CodonCoverageDataset(cds_file, bio_feat_file, allow_ids=None)
    print("[INFO]: Real loading transcript number (max-codon filter):", len(ds_probe))
    if len(ds_probe) > 0:
        _, _, bf0, _, _, _ = ds_probe[0]
        bio_dim = bf0.shape[1]

    ds = ds_probe
    if len(ds) < 5:
        print(f"[WARN] Too few training transcripts in {cds_file}: {len(ds)}")

    # train_split==1.0 -> no test set
    if train_split >= 1.0 or int(train_split * len(ds)) >= len(ds):
        n_tr = len(ds)
        tr = ds
        te = None
    else:
        n_tr = max(1, int(train_split * len(ds)))
        tr, te = random_split(ds, [n_tr, len(ds) - n_tr])

    tr_lengths = [tr[i][5] for i in range(len(tr))]
    batch_sampler = SortishBatchSampler(tr_lengths, batch_size=batch_size, seed=123, chunk_size_mult=50)

    tr_ld = DataLoader(
        tr,
        batch_sampler=batch_sampler,
        collate_fn=collate_varlen,
        drop_last=False,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=(num_workers > 0),
    )

    te_ld = None
    if te is not None and len(te) > 0:
        te_ld = DataLoader(te, batch_size=1, shuffle=False, collate_fn=collate_varlen, num_workers=0)

    dev = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    net = BiLSTMWithMRL(bio_feat_dim=bio_dim).to(dev)
    opt = optim.Adam(net.parameters(), 1e-3)

    for ep in range(1, epochs + 1):
        net.train()
        s_mse = s_wmse = s_acc = 0.0
        mrl_T, mrl_P = [], []

        # 训练进度条（每个 epoch）
        for cod, feat, cov, msk, mrl, lengths, _ids in tr_ld:
            cod, feat, cov, msk, mrl, lengths = [
                t.to(dev, non_blocking=True) for t in (cod, feat, cov, msk, mrl, lengths)
            ]
            y, m = net(cod, feat, lengths)
            loss = wmse_mask(y, cov, msk) + nn.functional.mse_loss(m, mrl)

            opt.zero_grad()
            loss.backward()
            opt.step()

            s_mse += mse_mask(y, cov, msk).item()
            s_wmse += wmse_mask(y, cov, msk).item()
            s_acc += bin_acc_mask(y, cov, msk)
            mrl_T.extend(mrl.detach().cpu().numpy().tolist())
            mrl_P.extend(m.detach().cpu().numpy().tolist())

            #tr_bar.set_postfix({"loss": f"{loss.item():.4f}"})

        pr = pearsonr(mrl_T, mrl_P)[0] if len(set(mrl_T)) > 1 else float("nan")
        sp = spearmanr(mrl_T, mrl_P)[0] if len(set(mrl_T)) > 1 else float("nan")
        denom = max(1, len(tr_ld))
        print(
            f"Ep{ep:02d} | MSE {s_mse/denom:.4f} | W-MSE {s_wmse/denom:.4f} | "
            f"BinAcc {s_acc/denom:.4f} | MRL_Pearson {pr:.3f} | MRL_Spearman {sp:.3f}"
        )

    return net, te_ld, dev


def run_prediction(model, device, npz_path, allow_ids=None,
                   bio_feat_file=None, max_codons=1000, pred_batch_size=8):

    if allow_ids is None:
        raise ValueError("allow_ids must be provided for prediction.")

    pred_out = {}

    allow_ids = list(allow_ids)
    ds = CodonCoverageDataset(
        npz_path,
        bio_feat_file,
        max_codons=max_codons,
        allow_ids=set(allow_ids),
    )

    id_to_item = {item[0]: item for item in ds.items}
    ordered_items = [id_to_item[tid] for tid in allow_ids if tid in id_to_item]

    class _PredDS(Dataset):
        def __init__(self, items):
            self.items = items
        def __len__(self):
            return len(self.items)
        def __getitem__(self, i):
            return self.items[i]

    pds = _PredDS(ordered_items)

    ld = DataLoader(
        pds,
        batch_size=pred_batch_size,
        shuffle=False,
        collate_fn=collate_varlen,
        num_workers=0,
    )

    model.eval()

    total_tx = len(ordered_items)

    pred_bar = tqdm(
        ld,
        total=total_tx,
        desc="Predicting transcripts",
        unit="tx"
    )

    with torch.no_grad():
        for cod, bf, cov, msk, mrl, lengths, ids in ld:
            cod, bf, msk, lengths = [
                t.to(device, non_blocking=True)
                for t in (cod, bf, msk, lengths)
            ]

            y, _ = model(cod, bf, lengths)

            for i, tid in enumerate(ids):
                v = msk[i].bool()
                pred_cov = y[i][v].detach().cpu().numpy()
                pred_out[tid] = {"cds": {"pred_cov": pred_cov}}

            # ⭐ 更新真实 transcript 数
            pred_bar.update(len(ids))

    pred_bar.close()

    return pred_out

def compute_and_plot_results(model, test_loader, device, save_case_dir: str = "./reports", sample_key: str = "test"):
    # 如果没有 test_loader，直接跳过（train_split==1.0）
    if test_loader is None:
        return
    try:
        if hasattr(test_loader, "dataset") and len(test_loader.dataset) == 0:
            return
    except Exception:
        pass

    model.eval()
    cov_preds_all, cov_trues_all = [], []
    mrl_preds_all, mrl_trues_all = [], []
    binacc_sum, binacc_n = 0.0, 0

    # Save per-transcript case-study profiles (True/Pred) for supplementary visualization.
    # Key: transcript_id, Value: 1D numpy array (unpadded, masked)
    case_true = {}
    case_pred = {}

    with torch.no_grad():
        for cod, feat, cov, msk, mrl, lengths, _ids in test_loader:
            cod, feat, cov, msk, mrl, lengths = [t.to(device) for t in (cod, feat, cov, msk, mrl, lengths)]
            y, m = model(cod, feat, lengths)

            # Batch-safe export and metric aggregation
            # _ids is a list/tuple of length B (from collate_varlen)
            B = y.shape[0]
            ids = list(_ids) if isinstance(_ids, (list, tuple)) else [str(_ids)]
            if len(ids) != B:
                ids = [str(x) for x in ids]
                if len(ids) != B:
                    ids = [f"{sample_key}__idx{i}" for i in range(B)]

            for i in range(B):
                v = msk[i].bool()
                y_np = y[i][v].detach().cpu().numpy()
                cov_np = cov[i][v].detach().cpu().numpy()

                cov_preds_all.append(y_np)
                cov_trues_all.append(cov_np)

                tid = str(ids[i])
                case_pred[tid] = y_np
                case_true[tid] = cov_np

                # m is the MRL head output; keep per-transcript values
                try:
                    mrl_preds_all.append(float(m[i].item()))
                except Exception:
                    mrl_preds_all.append(float(m.item()))
                mrl_trues_all.append(float(mrl[i].item()))

            binacc_sum += bin_acc_mask(y, cov, msk)
            binacc_n += 1

    if len(cov_preds_all) and len(cov_trues_all):
        cov_pred = np.concatenate(cov_preds_all)
        cov_true = np.concatenate(cov_trues_all)
        cov_pearson = pearsonr(cov_pred, cov_true)[0] if np.std(cov_pred) > 0 and np.std(cov_true) > 0 else float("nan")
        cov_spearman = spearmanr(cov_pred, cov_true)[0] if len(cov_pred) > 1 else float("nan")
    else:
        cov_pearson = cov_spearman = float("nan")

    if len(mrl_preds_all) > 1 and np.std(mrl_preds_all) > 0 and np.std(mrl_trues_all) > 0:
        mrl_mse = float(np.mean((np.array(mrl_preds_all) - np.array(mrl_trues_all)) ** 2))
        mrl_pearson = pearsonr(mrl_preds_all, mrl_trues_all)[0]
        mrl_spearman = spearmanr(mrl_preds_all, mrl_trues_all)[0]
    else:
        mrl_mse = mrl_pearson = mrl_spearman = float("nan")

    test_binacc = (binacc_sum / binacc_n) if binacc_n > 0 else float("nan")

    print(f"[TEST] Coverage Pearson: {cov_pearson:.4f} | Spearman: {cov_spearman:.4f}")
    print(f"[TEST] MRL MSE: {mrl_mse:.4f} | Pearson: {mrl_pearson:.4f} | Spearman: {mrl_spearman:.4f}")
    print(f"[TEST] BinAcc: {test_binacc:.4f}")

    # Export case-study NPZs for reproducible downstream visualization.
    try:
        os.makedirs(save_case_dir, exist_ok=True)
        pred_path = os.path.join(save_case_dir, f"{sample_key}_case_pred.npz")
        true_path = os.path.join(save_case_dir, f"{sample_key}_case_true.npz")
        if len(case_pred) == 0 or len(case_true) == 0:
            raise RuntimeError("case_pred/case_true are empty; check that test_loader produced batches")
        np.savez_compressed(pred_path, **case_pred)
        np.savez_compressed(true_path, **case_true)
        print(f"[TEST] Saved case-study NPZ: {true_path} and {pred_path}")
    except Exception as e:
        print(f"[WARN] Failed to save case-study NPZs: {e}")


# ---------- Main pipeline ----------
def run_train_pipeline(
    coverage_csv,
    npz_dir,
    bio_feat=None,
    threshold="P75",
    empirical_cut=0.5,
    sample_name=None,
    epochs=100,
    train_split=0.9,
    max_codons=1000,
    batch_size=64,
    num_workers=8,
    pred_batch_size=8,
    seed=123,
    output_dir=".",
):
    set_seed(seed)

    cov_df = pd.read_csv(coverage_csv, index_col=0)

    # Filter NPZ files (exclude feature files such as bio_features.npz)
    npz_files = sorted(
        [
            f
            for f in glob.glob(os.path.join(npz_dir, "*.npz"))
            if "features" not in os.path.basename(f)
        ]
    )

    # Restrict to a specific sample if sample_name is provided
    if sample_name:
        npz_files = [p for p in npz_files if os.path.basename(p) == sample_name]
        if not npz_files:
            raise ValueError(f"Sample not found: {sample_name}")

    # Define output directories
    output_dir = os.path.abspath(output_dir)
    saved_model_dir = os.path.join(output_dir, "saved_model")
    pred_raw_dir = os.path.join(output_dir, "pred_raw")
    pred_compact_dir = os.path.join(output_dir, "pred_compact")
    reports_dir = os.path.join(output_dir, "reports")

    os.makedirs(saved_model_dir, exist_ok=True)
    os.makedirs(pred_raw_dir, exist_ok=True)
    os.makedirs(pred_compact_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    # Global timing statistics
    total_start_time = time.time()
    total_train_time = 0.0
    total_pred_time = 0.0
    processed = 0
    skipped = 0

    # Iterate through samples
    for npz_path in npz_files:
        sample_file = os.path.basename(npz_path)          # e.g. sample.npz
        sample_key = os.path.splitext(sample_file)[0]     # e.g. sample

        print(f"\n=== Processing sample: {sample_file} ===")

        # --------------------------------------------------
        # 1) Select training transcripts
        # --------------------------------------------------
        # Coverage matrix column names usually do not contain ".npz"
        # Try to match using sample_key first
        col_name = None
        if sample_key in cov_df.columns:
            col_name = sample_key
        elif sample_file in cov_df.columns:
            col_name = sample_file
        else:
            # Fallback: fuzzy matching
            for c in cov_df.columns:
                if sample_key.startswith(c) or c.startswith(sample_key):
                    col_name = c
                    break

        if col_name is None:
            print(f"[WARN] Column for sample '{sample_key}' not found in coverage matrix; skipping.")
            skipped += 1
            continue

        series = cov_df[col_name]
        thr = compute_threshold(series, which=threshold)

        npzd = load_npz_as_dict(npz_path)
        train_ids, pred_ids = [], []

        # Split transcripts into training and prediction sets
        for tid in npzd.keys():
            ent = npzd[tid]
            if "cds" not in ent:
                continue

            cov = np.asarray(ent["cds"].get("avg_count_norm", []), np.float32)
            if cov.size == 0:
                continue

            mean_cov = empirical_cov_mean(cov)
            val = float(series[tid]) if tid in series.index else -np.inf

            if (val > thr) and (mean_cov > empirical_cut):
                train_ids.append(tid)
            else:
                pred_ids.append(tid)

        print(f"[INFO] Train: {len(train_ids)} | Pred: {len(pred_ids)}")

        if len(train_ids) < 50:
            print("[WARN] Too few training transcripts; skipping this sample.")
            skipped += 1
            continue

        processed += 1

        # --------------------------------------------------
        # 2) Compute codon usage divergence (JSD)
        # --------------------------------------------------
        P = codon_freqs_for_set(npzd, train_ids)
        Q = codon_freqs_for_set(npzd, pred_ids)
        d_jsd = jsd(P, Q)
        print(f"[REPORT] JSD={d_jsd:.4f}")

        # --------------------------------------------------
        # 3) Train model
        # --------------------------------------------------
        tmp_train_npz = os.path.join(reports_dir, f"{sample_key}_TRAIN_ONLY.npz")
        np.savez_compressed(tmp_train_npz, **{k: npzd[k] for k in train_ids})

        t0 = time.time()
        model, test_loader, device = train_model(
            tmp_train_npz,
            bio_feat,
            epochs=epochs,
            train_split=train_split,
            batch_size=batch_size,
            num_workers=num_workers,
        )
        t_train = time.time() - t0
        total_train_time += t_train

        # Save trained model
        torch.save(model.state_dict(), os.path.join(saved_model_dir, f"{sample_key}.pt"))

        # Evaluate model and generate diagnostic plots
        compute_and_plot_results(
            model,
            test_loader,
            device,
            save_case_dir=reports_dir,
            sample_key=sample_key,
        )

        # --------------------------------------------------
        # 4) Run prediction
        # --------------------------------------------------
        t0 = time.time()
        pred_dict = run_prediction(
            model,
            device,
            npz_path,
            allow_ids=pred_ids,
            bio_feat_file=bio_feat,
            max_codons=max_codons,
            pred_batch_size=pred_batch_size,
        )
        t_pred = time.time() - t0
        total_pred_time += t_pred

        # Save prediction outputs
        save_pred_raw_npz(
            os.path.join(pred_raw_dir, f"{sample_key}_pred_raw.npz"),
            pred_dict,
        )

        save_pred_compact_csv(
            os.path.join(pred_compact_dir, f"{sample_key}_pred_compact.csv"),
            pred_dict,
        )

    total_time = time.time() - total_start_time

    # --------------------------------------------------
    # Pipeline summary
    # --------------------------------------------------
    print("\n==================== SUMMARY ====================")
    print(f"[SUMMARY] Output directory:    {output_dir}")
    print(f"[SUMMARY] Samples total:       {len(npz_files)}")
    print(f"[SUMMARY] Samples processed:   {processed}")
    print(f"[SUMMARY] Samples skipped:     {skipped}")
    print(f"[TIME] Total training time:    {total_train_time:.2f} sec")
    print(f"[TIME] Total prediction time:  {total_pred_time:.2f} sec")
    print(f"[TIME] Total pipeline time:    {total_time:.2f} sec")
    print("=================================================")

    print("\nAll done.")


# if __name__ == "__main__":
#     run_train_pipeline(...)