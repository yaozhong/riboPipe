from __future__ import annotations

import argparse
import sys

from .builder import csv_to_npz_dir
from .matrix import build_coverage_matrix
from .biofeat import build_bio_features
from .train_pipeline import run_train_pipeline


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ribopipe", description="Ribo-seq preprocessing + feature generation toolkit")
    sub = ap.add_subparsers(dest="cmd", required=True)

    # preprocess
    ap_p = sub.add_parser("preprocess", help="Convert one CSV to per-condition NPZ files")
    ap_p.add_argument("--csv", required=True)
    ap_p.add_argument("--fasta", required=True)
    ap_p.add_argument("--out-dir", required=True)
    ap_p.add_argument("--fasta-cache", default=None, help="Optional pickle path for cached fasta dict")

    # matrix
    ap_m = sub.add_parser("matrix", help="Build transcript x sample coverage matrix from NPZ directory")
    ap_m.add_argument("--npz-dir", required=True)
    ap_m.add_argument("--out-csv", required=True)
    ap_m.add_argument("--no-sorted", action="store_true", help="Do not write per-sample sorted tables")

    # biofeat
    ap_b = sub.add_parser("biofeat", help="Generate per-codon biological features from an NPZ")
    ap_b.add_argument("--cds-npz", required=True, help="Any NPZ containing transcripts with cds.sequence")
    ap_b.add_argument("--trna-json", required=True)
    ap_b.add_argument("--out-npz", required=True)

    # train_pipeline
    ap_t = sub.add_parser("train_pipeline", help="Train model pipeline")
    ap_t.add_argument("--coverage-csv", required=True)
    ap_t.add_argument("--npz-dir", required=True)
    ap_t.add_argument("--bio-feat")
    ap_t.add_argument("--threshold", choices=["P75", "P95"], default="P75")
    ap_t.add_argument("--empirical-cut", type=float, default=0.5)
    ap_t.add_argument("--sample-name")
    ap_t.add_argument("--epochs", type=int, default=200)
    ap_t.add_argument("--train-split", type=float, default=1.0)
    ap_t.add_argument("--max-codons", type=int, default=1000)
    ap_t.add_argument("--batch-size", type=int, default=64)
    ap_t.add_argument("--num-workers", type=int, default=8)
    ap_t.add_argument("--pred-batch-size", type=int, default=64)

    args = ap.parse_args(argv)

    if args.cmd == "preprocess":
        written = csv_to_npz_dir(args.csv, args.fasta, args.out_dir, fasta_cache=args.fasta_cache)
        for p in written:
            print(p)
        return 0

    if args.cmd == "matrix":
        out = build_coverage_matrix(args.npz_dir, args.out_csv, write_sorted_tables=not args.no_sorted)
        print(out)
        return 0

    if args.cmd == "biofeat":
        out = build_bio_features(args.cds_npz, args.trna_json, args.out_npz)
        print(out)
        return 0

    if args.cmd == "train_pipeline":
        run_train_pipeline(coverage_csv=args.coverage_csv, npz_dir=args.npz_dir, \
                           bio_feat=args.bio_feat,threshold=args.threshold,empirical_cut=args.empirical_cut,\
                           sample_name=args.sample_name,epochs=args.epochs,train_split=args.train_split,\
                           max_codons=args.max_codons,batch_size=args.batch_size,num_workers=args.num_workers,\
                           pred_batch_size=args.pred_batch_size,)
        return 0

    ap.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
